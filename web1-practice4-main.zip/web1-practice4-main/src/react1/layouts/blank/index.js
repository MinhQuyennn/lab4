import { Outlet } from "react-router-dom";

const Blank = () => {
  return (
    <>
      <Outlet />
    </>
  );
};

export default Blank;
